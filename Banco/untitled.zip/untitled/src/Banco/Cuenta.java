package Banco;

public class Cuenta {
    private Integer numeroCuenta;
    private Double saldo;
    private Cliente titular;

    public Cuenta (Integer numeroCuenta, Double saldo, Cliente titular){
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldo;
        this.titular = titular;
    }

    public void deposito(Double cantidadDinero){
        saldo = saldo + cantidadDinero;
        System.out.println("hiciste un deposito de " + cantidadDinero);
        System.out.println("tu saldo es " + saldo);
    }

    public void extraccion (Double cantidadDinero){
        if(cantidadDinero < saldo){
            saldo = saldo - cantidadDinero;
            System.out.println("hiciste una extraccion de " + cantidadDinero);
            System.out.println("tu saldo es: " + saldo);
        } else{
            System.out.println("no tenes saldo para extraer " + cantidadDinero);
        }
    }

    public Integer getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(Integer numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public Double getSaldo() {
        return saldo;
    }

    public void setSaldo(Double saldo) {
        this.saldo = saldo;
    }

    public Cliente getTitular() {
        return titular;
    }

    public void setTitular(Cliente titular) {
        this.titular = titular;
    }
}
