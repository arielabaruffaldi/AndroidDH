package Banco;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Cliente clienteUno = new Cliente ("Ariela", "Baruffaldi");

        Cuenta cuentaClienteUno = new Cuenta (1234, 100.0, clienteUno);

        cuentaClienteUno.deposito(300.15);

        cuentaClienteUno.extraccion(600.0);

    }
}
