package Banco;

public class Cliente {

    private String nombre;
    private String apellido;
    public Cliente (String nombre, String apellido){
        this.nombre = nombre;
        this.apellido = apellido;
    }
}
