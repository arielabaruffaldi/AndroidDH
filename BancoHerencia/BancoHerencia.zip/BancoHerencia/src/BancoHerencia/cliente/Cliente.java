package BancoHerencia.cliente;

public class Cliente {

    private Integer identificador;

    public Cliente(Integer identificador) {
        this.identificador = identificador;
    }
}
